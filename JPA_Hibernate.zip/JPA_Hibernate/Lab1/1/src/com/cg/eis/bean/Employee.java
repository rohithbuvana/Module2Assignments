
package com.cg.eis.bean;

import java.util.Comparator;

public class Employee implements Comparable,Comparator {
public Employee(int eId, String eName, double salary) {
		super();
		this.eId = eId;
		this.eName = eName;
		this.salary = salary;
	}
int eId;
String eName,designation,insuranceScheme;
double salary;
public int geteId() {
	return eId;
}
public void seteId(int eId) {
	this.eId = eId;
}
public String geteName() {
	return eName;
}
public void seteName(String eName) {
	this.eName = eName;
}
public String getDesignation() {
	return designation;
}
public void setDesignation(String designation) {
	this.designation = designation;
}
public String getInsuranceScheme() {
	return insuranceScheme;
}
public void setInsuranceScheme(String insuranceScheme) {
	this.insuranceScheme = insuranceScheme;
}
public double getSalary() {
	return salary;
}
public void setSalary(double salary) {
	this.salary = salary;
}
public Employee(int eId, String eName, String designation, String insuranceScheme, double salary) {
	super();
	this.eId = eId;
	this.eName = eName;
	this.designation = designation;
	this.insuranceScheme = insuranceScheme;
	this.salary = salary;
}
public Employee() {
	super();
}
@Override
public String toString() {
	return "Employee [eId=" + eId + ", eName=" + eName + ", designation=" + designation + ", insuranceScheme="
			+ insuranceScheme + ", salary=" + salary + "]";
}
@Override
public int compareTo(Object o) {
	
	if(this.getSalary()<((Employee)o).getSalary())
	return 1;
	else if(this.getSalary()>((Employee)o).getSalary())
		return -1;
	else
		return 0;

}
@Override
public int compare(Object o1, Object o2) {
	if(((Employee)o1).getSalary()<((Employee)o2).getSalary())
		return 1;
		else if(((Employee)o1).getSalary()>((Employee)o2).getSalary())
			return -1;
		else
			return 0;
	
}

}
