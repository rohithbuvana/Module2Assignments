
package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.EmployeeInsuranceSystem;
import com.cg.eis.service.EmployeeServiceImpl;

public class EmployeeMain {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int count;
		EmployeeServiceImpl esi = new EmployeeServiceImpl();
		char s='n';
		do
		{
		System.out.println("\nMenu\n1.Add Employee\n2.Search employee of a particular scheme\n3.Delete a employee");
		System.out.println("Enter the choice ");
		int ch=sc.nextInt();
		switch (ch) {
		case 1:
			System.out.println("Enter the number of Employees: ");
			count = sc.nextInt();
			EmployeeInsuranceSystem eis = new EmployeeInsuranceSystem();
			for (int i = 0; i < count; i++) {
				Employee emp = new Employee();
				System.out.println("\nEnter the Employee Id: ");
				emp.seteId(sc.nextInt());
				System.out.println("Enter the Employee Name: ");
				emp.seteName(sc.next());
				System.out.println("Enter the Salary: ");
				emp.setSalary(sc.nextDouble());
				eis.findInsurance(emp);
				esi.addEmployee(emp);
			}
			break;
		case 2:
			System.out.println("Enter the scheme of the employees to display ");
			String scheme = sc.next().toLowerCase();
			esi.displayEmployee(scheme);
			break;
		case 3:
			System.out.println("Enter the id of the employee to delete ");
			int id = sc.nextInt();
			if (esi.deleteEmployee(id)) {
				System.out.println("Successfully Deleted");
			} else
				System.out.println("No Employee with given id to be Deleted");
			break;
		
		}
		System.out.println("Do you want to continue (y/n) ");
		s=sc.next().toLowerCase().charAt(0);
		}while(s=='y');
		sc.close();
	}
}
