package com.cg.eis.service;



import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import com.cg.eis.bean.Employee;

public class EmployeeServiceImpl {

	Connection con;
	public EmployeeServiceImpl() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
		String url="jdbc:mysql://localhost:3306/db";
		String uid="root";
		String pwd="corp123";
		this.con=DriverManager.getConnection(url,uid,pwd);
		}
		catch(SQLException | ClassNotFoundException e)
		{
			e.printStackTrace();
		}
	}

	public void addEmployee(Employee emp) {
		String query="insert into employee(name,id,insurancescheme,salary) values(\'"+emp.geteName() +"\',"+emp.geteId() +",\'"+emp.getInsuranceScheme() +"\',"+emp.getSalary() +")";
		try {
			con.setAutoCommit(false);
			java.sql.Statement stmt= con.createStatement();
			stmt.execute(query);
			con.commit();
			
		} catch (SQLException e) {
			
			e.printStackTrace();
			
		}
	}

	public boolean deleteEmployee(int id) {
		String query=" delete from employee  where id="+id;
		try {
			con.setAutoCommit(false);
			java.sql.Statement stmt1= con.createStatement();
			stmt1.execute(query);
			con.commit();
			return true;
		} catch (SQLException e) {
			
			e.printStackTrace();
			return false;
		}
		
	}

	public void displayEmployee(String scheme) {
		Employee employee=new Employee();
		String query="select * from employee where insurancescheme=\'"+ scheme+"\'" ;
		try {
			con.setAutoCommit(false);
			java.sql.Statement stmt= con.createStatement();
			ResultSet rs=stmt.executeQuery(query);
			while(rs.next())
			{
				System.out.println("Id :" +rs.getInt(2) );
				System.out.println("Name :" +rs.getString(1) );
				System.out.println("Salary :" + rs.getFloat(4));
				System.out.println("Designation :" + rs.getString(3));
			}
		
		} catch (SQLException e) {
			
			e.printStackTrace();
		}	
	}

	
		
		

}
