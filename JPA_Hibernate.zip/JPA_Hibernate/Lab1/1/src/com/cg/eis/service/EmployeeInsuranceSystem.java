
package com.cg.eis.service;



import com.cg.eis.bean.Employee;

public class EmployeeInsuranceSystem implements EmployeeService  {

	
	public void findInsurance(Employee emp) {

		if (emp.getSalary() > 5000 && emp.getSalary() < 20000) {
			emp.setInsuranceScheme("SchemeC");
			emp.setDesignation("System Associate");
			System.out.println("Insutance Scheme: "+emp.getInsuranceScheme());
		} 
		else if (emp.getSalary() >= 20000 && emp.getSalary() < 40000) {
			emp.setInsuranceScheme("SchemeB");
			emp.setDesignation("Programmer");
			System.out.println("Insutance Scheme: "+emp.getInsuranceScheme());
		} else if (emp.getSalary() >= 40000) {
			emp.setInsuranceScheme("SchemeA");
			emp.setDesignation("Manager");
			System.out.println("Insutance Scheme: "+emp.getInsuranceScheme());
		} else {
			emp.setInsuranceScheme("NoScheme");
			emp.setDesignation("Clerk");
			System.out.println("Insutance Scheme: "+emp.getInsuranceScheme());
		}
	}



}
