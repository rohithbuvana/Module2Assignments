package com.capgemini.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.capgemini.entity.Author;

public class Client {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	int count;
	char s='n';
	do
	{
	System.out.println("\nMenu\n1.Add Author\n2.Update Author Phone No\n3.Display particular author\n4.Delete Author");
	System.out.println("Enter the choice ");
	int ch=sc.nextInt();
	switch (ch) {
	case 1:
		System.out.println("Enter the number of Employees: ");
		count = sc.nextInt();
		for (int i = 0; i < count; i++) {
			Author author = new Author();
			System.out.println("\nEnter the Author Id: ");
			author.setAuthorId(sc.nextInt());
			System.out.println("Enter First Name: ");
			author.setFirstName(sc.next());
			System.out.println("Enter the Middle Name: ");
			author.setMiddleName(sc.next());
			System.out.println("Enter the Last Name: ");
			author.setLastName(sc.next());
			System.out.println("Enter the Phone No: ");
			author.setMiddleName(sc.next());
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("AuthorJPA");
			 EntityManager em=emf.createEntityManager();
				EntityTransaction tx=em.getTransaction();
				tx.begin();
				em.persist(author);
				tx.commit();
				em.close();
		}
		break;
	case 2:
		System.out.println("Enter the id of the author to update ");
		int id=sc.nextInt();
		System.out.println("Enter the new phone number ");
		String pno=sc.next();
		Author author=new Author();
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("AuthorJPA");
		 EntityManager em=emf.createEntityManager();
			EntityTransaction tx=em.getTransaction();
			tx.begin();
			author=em.find(Author.class,id);
			author.setPhoneno(pno);
			em.merge(author);
			tx.commit();
			em.close();
		break;
	case 3:
		System.out.println("Enter the id of the author to update ");
		id=sc.nextInt();
		author=new Author();
		EntityManagerFactory emf1=Persistence.createEntityManagerFactory("AuthorJPA");
		 EntityManager em1=emf1.createEntityManager();
			EntityTransaction tx1=em1.getTransaction();
			tx1.begin();
			author=em1.find(Author.class,id);
			tx1.commit();
			em1.close();
			System.out.println(author);
		break;
	case 4:
		System.out.println("Enter the id of the author to delete ");
		id = sc.nextInt();
		EntityManagerFactory emf2=Persistence.createEntityManagerFactory("AuthorJPA");
		 EntityManager em2=emf2.createEntityManager();
			EntityTransaction tx2=em2.getTransaction();
			tx2.begin();
			author=em2.find(Author.class,id);
			em2.remove(author);;
			tx2.commit();
			em2.close();
		break;
	
	}
	System.out.println("Do you want to continue (y/n) ");
	s=sc.next().toLowerCase().charAt(0);
	}while(s=='y');
	sc.close();
}
}
