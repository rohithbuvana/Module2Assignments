package com.capgemini.bean;

public class Employee {
private int employeeId;
private String employeeName;
private double salary;
private SBU businessUnit;

public SBU getBusinessUnit() {
	return businessUnit;
}
public void setBusinessUnit(SBU businessUnit) {
	this.businessUnit = businessUnit;
}
public int getEmployeeId() {
	return employeeId;
}
public void setEmployeeId(int employeeId) {
	this.employeeId = employeeId;
}
public String getEmployeeName() {
	return employeeName;
}
public void setEmployeeName(String employeeName) {
	this.employeeName = employeeName;
}
public double getSalary() {
	return salary;
}
@Override
public String toString() {
	return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", salary=" + salary
			+ "\n sbu details=" + getSbuDetails() + "]";
}
public void setSalary(double salary) {
	this.salary = salary;
}

public Employee() {
	super();
}
public SBU getSbuDetails()
{
	return businessUnit;
	
}
}
