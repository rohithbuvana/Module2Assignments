package com.capgemini.pl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee;

public class MainApp {
	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		context.registerShutdownHook();
		Employee employee = (Employee) context.getBean("employee");
		System.out.println(employee);
	}

}
