package com.capgemini.pl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.Employee;

public class MainApp {
public static void main(String[] args) {
	AbstractApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
	context.registerShutdownHook();
	Employee employee=(Employee) context.getBean("employee");
	System.out.println("Employee Details");
	System.out.println("------------------------------------------------");
	System.out.println("Employee Id : "+employee.getEmployeeId());
	System.out.println("Employee Name : "+employee.getEmployeeName());
	System.out.println("Employee Salary : "+employee.getSalary());
	System.out.println("Employee BU :"+employee.getBusinessUnit());
	System.out.println("Employee Age : "+employee.getAge());
}
}
