package com.capgemini.pl;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.capgemini.bean.SBU;

public class MainApp {
	public static void main(String[] args) {
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		context.registerShutdownHook();
		SBU sbu = (SBU) context.getBean("sbu");
		System.out.println(sbu);
	}

}
